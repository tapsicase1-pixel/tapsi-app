/* نرخ‌یاب — کلاینت وب داخل WebView.  همه‌ی آدرس‌ها: /api/v1/...  */
const $ = (s) => document.querySelector(s), $$ = (s) => [...document.querySelectorAll(s)];
const NATIVE = typeof Android !== "undefined";
const BASE = (localStorage.getItem("base") || window.API_BASE || "").replace(/\/$/, "");
const API = BASE + "/api/v1";
const fa = (n, d = 0) => Number(n).toLocaleString("fa-IR", { maximumFractionDigits: d });
let S = JSON.parse(localStorage.getItem("sess") || "null");   // {token, role, name, can_mute}
let nav = ["home"];

function toast(t) { const e = $("#toast"); e.textContent = t; e.classList.remove("hidden"); clearTimeout(toast.t); toast.t = setTimeout(() => e.classList.add("hidden"), 2800); }
function show(id) { $$(".page").forEach((p) => p.classList.add("hidden")); $("#" + id).classList.remove("hidden"); nav.push(id); }
function back() { if (nav.length > 1) { nav.pop(); const id = nav[nav.length - 1]; nav.pop(); show(id); if (id === "home") stopFeed(); return true; } return false; }
window.onBackKey = () => (nav[nav.length - 1] !== "home" ? back() : false);
$$("[data-back]").forEach((b) => (b.onclick = back));

async function api(path, method = "GET", body, token = S && S.token, timeout = 35000) {
  const ctl = new AbortController(); const t = setTimeout(() => ctl.abort(), timeout);
  try {
    const r = await fetch(API + path, { method, signal: ctl.signal, headers: { "Content-Type": "application/json", ...(token ? { Authorization: "Bearer " + token } : {}) }, body: body ? JSON.stringify(body) : undefined });
    if (r.status === 401 && S) { logout(true); }
    return await r.json();
  } catch (e) { return { ok: false, error: "network" }; } finally { clearTimeout(t); }
}

/* ---------------- قیمت‌ها ---------------- */
const hist = JSON.parse(localStorage.getItem("hist") || "{}");
let prices = [], curSym = null, curRes = "60";
function spark(c, arr, up) {
  const w = (c.width = 140), h = (c.height = 56), x = c.getContext("2d"); x.clearRect(0, 0, w, h);
  if (arr.length < 2) return;
  const mn = Math.min(...arr), mx = Math.max(...arr) || 1, r = mx - mn || 1;
  x.beginPath(); arr.forEach((v, i) => { const px = (i / (arr.length - 1)) * w, py = h - 4 - ((v - mn) / r) * (h - 8); i ? x.lineTo(px, py) : x.moveTo(px, py); });
  x.strokeStyle = up ? "#2ecc71" : "#ff5c5c"; x.lineWidth = 3; x.stroke();
}
async function loadPrices() {
  const r = await api("/market/prices", "GET", null, null, 12000);
  if (!r.ok || !r.items.length) { $("#upd").textContent = "عدم اتصال"; return; }
  prices = r.items; $("#upd").textContent = "به‌روز: " + new Date().toLocaleTimeString("fa-IR", { hour: "2-digit", minute: "2-digit" });
  const box = $("#list"); box.innerHTML = "";
  prices.forEach((p) => {
    const h = (hist[p.sym] = (hist[p.sym] || []).concat(p.price).slice(-40));
    const d = document.createElement("div"); d.className = "item";
    const up = (p.change || 0) >= 0;
    d.innerHTML = `<div class="nm">${p.name}<small>${p.unit}</small></div><canvas></canvas><div class="pr ${up ? "up" : "down"}">${fa(p.price, p.price < 100 ? 2 : 0)}<small style="display:block;font-size:11px">${up ? "▲" : "▼"} ${fa(Math.abs(p.change || 0), 2)}٪</small></div>`;
    spark(d.querySelector("canvas"), h, up); d.onclick = () => openChart(p); box.appendChild(d);
  });
  localStorage.setItem("hist", JSON.stringify(hist));
}
async function openChart(p) {
  curSym = p.sym; $("#chTitle").textContent = p.name; $("#chPrice").textContent = fa(p.price) + " " + p.unit; show("chart"); drawChart();
}
async function drawChart() {
  const r = await api("/market/history?sym=" + curSym + "&res=" + curRes, "GET", null, null, 15000);
  const c = $("#cv"), w = (c.width = c.clientWidth * 2), h = (c.height = c.clientHeight * 2), x = c.getContext("2d");
  x.clearRect(0, 0, w, h); x.font = "26px sans-serif";
  const pts = (r.points || []).map((a) => a[1]); if (pts.length < 2) { x.fillStyle = "#7d8da0"; x.fillText("داده‌ی کافی نیست؛ چند دقیقه بعد دوباره ببین", 30, h / 2); return; }
  const mn = Math.min(...pts), mx = Math.max(...pts), rg = mx - mn || 1, pad = 60;
  x.beginPath(); pts.forEach((v, i) => { const px = pad + (i / (pts.length - 1)) * (w - pad * 2), py = h - pad - ((v - mn) / rg) * (h - pad * 2); i ? x.lineTo(px, py) : x.moveTo(px, py); });
  const up = pts[pts.length - 1] >= pts[0]; x.strokeStyle = up ? "#2ecc71" : "#ff5c5c"; x.lineWidth = 4; x.stroke();
  x.lineTo(w - pad, h - pad); x.lineTo(pad, h - pad); x.closePath(); const g = x.createLinearGradient(0, 0, 0, h); g.addColorStop(0, up ? "#2ecc7155" : "#ff5c5c55"); g.addColorStop(1, "#0000"); x.fillStyle = g; x.fill();
  x.fillStyle = "#9fb0c3"; x.fillText(fa(mx), 10, 34); x.fillText(fa(mn), 10, h - 14);
}
$$("#tfs button").forEach((b) => (b.onclick = () => { $$("#tfs button").forEach((x) => x.classList.remove("on")); b.classList.add("on"); curRes = b.dataset.r; drawChart(); }));

/* ---------------- جستجو = ورود ---------------- */
let kind = "buy";
function openSearch(k) { kind = k; $("#seInput").value = ""; $("#seMsg").textContent = ""; show("search"); setTimeout(() => $("#seInput").focus(), 200); }
$("#btnBuy").onclick = () => openSearch("buy");   // هر بار ورود کد در بخش جستجو
$("#btnSell").onclick = () => openSearch("sell");
const ERR = { bad_code: "نتیجه‌ای یافت نشد", locked: "تعداد تلاش زیاد است؛ کمی بعد دوباره", account_closed: "نتیجه‌ای یافت نشد", masseur_not_registered: "نتیجه‌ای یافت نشد", network: "اتصال برقرار نیست" };
async function doSearch() {
  const code = $("#seInput").value.trim(); if (!code) return;
  const dev = localStorage.getItem("dev") || (localStorage.setItem("dev", Math.random().toString(36).slice(2) + Date.now()), localStorage.getItem("dev"));
  const r = await api("/auth/login", "POST", { code, kind: kind === "buy" ? "buy" : "sell", device: dev }, null);
  if (r.reset) return resetFlow(r.reset_token);
  if (!r.ok) { $("#seMsg").textContent = ERR[r.error] || "نتیجه‌ای یافت نشد"; return; }
  S = { token: r.token, role: r.role, name: r.name, can_mute: r.can_mute }; localStorage.setItem("sess", JSON.stringify(S));
  localStorage.setItem("base", BASE);
  if (NATIVE) Android.saveSession(BASE, r.token, r.role);
  if (r.must_change) { toast("رمز مادر هنوز پیش‌فرض است؛ از «حساب‌ها» عوضش کن"); }
  nav.pop(); openPanel(r.must_change);
}
async function resetFlow(rt) {
  const np = prompt("بازنشانی انجام شد. رمز مادر جدید را وارد کن (حداقل ۴ حرف):"); if (!np) return;
  const r = await api("/auth/master/reset", "POST", { reset_token: rt, new_password: np }, null);
  toast(r.ok ? "رمز جدید ثبت شد؛ دوباره وارد شو" : "نشد: " + (r.error || ""));
}
$("#seGo").onclick = doSearch; $("#seInput").onkeydown = (e) => e.key === "Enter" && doSearch();
function logout(silent) { if (S) api("/auth/logout", "POST"); S = null; localStorage.removeItem("sess"); localStorage.removeItem("after"); if (NATIVE) Android.clearSession(); stopFeed(); nav = ["home"]; show("home"); nav = ["home"]; if (!silent) toast("خارج شدی"); }
$("#pnOut").onclick = () => logout();

/* ---------------- پنل ---------------- */
const staff = () => S && S.role !== "masseur";
function openPanel(mustChange) {
  if (!S) return; show("panel");
  $("#pnTitle").textContent = (S.role === "masseur" ? "پنل — " : S.role === "admin" ? "مدیریت — " : "اپراتور — ") + (S.name || "");
  $$("[data-staff]").forEach((b) => b.classList.toggle("hidden", !staff()));
  $("#accAdmin").classList.toggle("hidden", S.role !== "admin");
  $("#muteCard").classList.toggle("hidden", !S.can_mute);
  tab(mustChange ? "acc" : "feed"); startFeed(); pollAlarms();
}
function tab(t) { $$("#tabs button").forEach((b) => b.classList.toggle("on", b.dataset.t === t)); $$(".tab").forEach((e) => e.classList.add("hidden")); $("#t-" + t).classList.remove("hidden"); if (t === "inbox") loadThreads(); if (t === "acc") loadAcc(); }
$$("#tabs button").forEach((b) => (b.onclick = () => tab(b.dataset.t)));

/* --- آینه‌ی ربات --- */
let feedOn = false, after = 0, replyTo = null; const bubbles = {};
function stopFeed() { feedOn = false; }
async function startFeed() {
  if (feedOn) return; feedOn = true; $("#msgs").innerHTML = ""; $("#rkb").innerHTML = "";
  const first = await api("/feed?after=0", "GET"); after = first.ok && first.items.length ? first.items[first.items.length - 1].id : 0;
  await api("/say", "POST", { text: "/start" });
  while (feedOn && S) {
    const r = await api("/feed?after=" + after + "&wait=20", "GET");
    if (!r.ok) { await new Promise((z) => setTimeout(z, 4000)); continue; }
    r.items.forEach((it) => { after = Math.max(after, it.id); applyItem(it); });
  }
}
function applyItem(it) {
  const box = $("#msgs");
  if (it.op === "toast") return toast(it.text);
  if (it.op === "del") { bubbles[it.mid] && bubbles[it.mid].remove(); delete bubbles[it.mid]; return; }
  if (it.rkb !== null && it.rkb !== undefined) {
    const k = $("#rkb"); k.innerHTML = "";
    it.rkb.flat().forEach((t) => { const b = document.createElement("button"); b.textContent = t; b.onclick = () => sendText(t); k.appendChild(b); });
  }
  let el = bubbles[it.mid];
  if (it.op === "edit" && !el) return;
  if (!el) { el = document.createElement("div"); el.className = "bub"; box.appendChild(el); bubbles[it.mid] = el; }
  if (it.text || it.op === "new") { el.dataset.mid = it.mid; el.innerHTML = ""; const tx = document.createElement("div"); tx.textContent = it.text; el.appendChild(tx); }
  const old = el.querySelector(".ib"); if (it.kb) { old && old.remove(); const ib = document.createElement("div"); ib.className = "ib";
    it.kb.flat().forEach((b) => { const x = document.createElement("button"); x.textContent = b.t; x.onclick = () => (b.u && !b.d ? window.open(b.u) : press(b.d, it.mid)); ib.appendChild(x); }); el.appendChild(ib); }
  if (!el.querySelector(".rp")) { const rp = document.createElement("div"); rp.className = "rp"; rp.textContent = "↩️ پاسخ"; rp.onclick = () => { replyTo = it.mid; const t = $("#replyTag"); t.textContent = "پاسخ به پیام"; t.classList.remove("hidden"); $("#msgIn").focus(); }; el.appendChild(rp); }
  box.scrollTop = box.scrollHeight;
}
async function press(d, mid) { const r = await api("/press", "POST", { data: d, mid }); if (!r.ok) toast("انجام نشد"); }
async function sendText(t) {
  const el = document.createElement("div"); el.className = "bub me"; el.textContent = t; $("#msgs").appendChild(el); $("#msgs").scrollTop = 1e9;
  const r = await api("/say", "POST", { text: t, reply_to: replyTo }); replyTo = null; $("#replyTag").classList.add("hidden"); if (!r.ok) toast("ارسال نشد");
}
$("#msgGo").onclick = () => { const v = $("#msgIn").value.trim(); if (v) { $("#msgIn").value = ""; sendText(v); } };
$("#msgIn").onkeydown = (e) => e.key === "Enter" && $("#msgGo").click();
$("#replyTag").onclick = () => { replyTo = null; $("#replyTag").classList.add("hidden"); };

/* --- زنگ رزرو (نمایش داخل اپ؛ زنگ اصلی را سرویس اندروید می‌زند) --- */
let alarmItems = [];
async function pollAlarms() {
  while (S && !$("#panel").classList.contains("hidden")) {
    const r = await api("/alarms/pending?wait=15", "GET");
    if (r.ok) { alarmItems = r.items; const bar = $("#alarmBar"); bar.classList.toggle("hidden", !alarmItems.length);
      if (alarmItems.length) { const a = alarmItems[0]; $("#alarmTxt").textContent = "🔔 رزرو جدید — " + (a.ticker || "") + (a.when ? " | " + a.when : "") + (a.city ? " | " + a.city : ""); } }
    else await new Promise((z) => setTimeout(z, 4000));
  }
}
$("#alarmSeen").onclick = async () => { if (NATIVE) Android.seen(); await api("/alarms/seen", "POST", {}); $("#alarmBar").classList.add("hidden"); };

/* --- پیام مشتریان (بله/تلگرام) برای مدیریت و اپراتور --- */
let thr = null;
async function loadThreads() {
  $("#thread").classList.add("hidden"); const box = $("#threads"); box.classList.remove("hidden"); box.innerHTML = "";
  const r = await api("/inbox/threads"); if (!r.ok) return;
  r.items.forEach((t) => { const d = document.createElement("div"); d.className = "thr";
    d.innerHTML = `<b></b> <small></small><div></div>`; d.querySelector("b").textContent = t.name; d.querySelector("small").textContent = (t.source.startsWith("bale") ? "بله" : "تلگرام") + (t.mode === "manual" ? " • دستی" : "");
    d.lastChild.textContent = t.last; d.onclick = () => openThread(t); box.appendChild(d); });
  if (!r.items.length) box.textContent = "پیامی نیست.";
}
async function openThread(t) {
  thr = t; $("#threads").classList.add("hidden"); $("#thread").classList.remove("hidden"); $("#thMode").value = t.mode;
  const r = await api(`/inbox/thread?source=${t.source}&user_id=${t.user_id}`); const box = $("#thMsgs"); box.innerHTML = "";
  (r.items || []).forEach((m) => { const e = document.createElement("div"); e.className = "bub " + (m.dir === "out" ? "me" : "cust"); e.textContent = m.text; box.appendChild(e); }); box.scrollTop = 1e9;
}
$("#thBack").onclick = loadThreads;
$("#thGo").onclick = async () => { const v = $("#thIn").value.trim(); if (!v || !thr) return; $("#thIn").value = ""; const r = await api("/ub/outbox", "POST", { source: thr.source, user_id: thr.user_id, text: v }); toast(r.ok ? "ارسال شد" : "ارسال نشد"); openThread(thr); };
$("#thSetMode").onclick = async () => { await api("/ub/mode", "POST", { source: thr.source, user_id: thr.user_id, mode: $("#thMode").value, hours: 6 }); toast("ثبت شد"); };

/* --- حساب‌ها --- */
let dir = null;
async function loadAcc() {
  if (S.role === "admin") { dir = dir || (await api("/admin/directory")); fillRef(); }
  const r = await api("/admin/accounts"); const box = $("#accList"); box.innerHTML = "";
  (r.items || []).forEach((a) => { const d = document.createElement("div"); d.className = "acc";
    d.innerHTML = `<span></span><button class="small"></button>`; d.firstChild.textContent = (a.role === "masseur" ? "ماسور " : "اپراتور ") + (a.name || a.ref) + " (" + a.ref + ")" + (a.active ? "" : " — بسته");
    const b = d.lastChild; b.textContent = a.active ? "بستن حساب" : "باز کردن"; b.onclick = async () => { const x = await api(`/admin/accounts/${a.id}/active`, "POST", { active: !a.active }); toast(x.ok ? "انجام شد" : "نشد"); loadAcc(); }; box.appendChild(d); });
}
function fillRef() {
  const s = $("#acRef"), role = $("#acRole").value; s.innerHTML = "";
  const L = role === "masseur" ? (dir.masseurs || []).map((m) => [m.code, "ماسور " + m.code + " — " + (m.name || "")]) : (dir.operators || []).map((o) => [o.user_id, "اپراتور " + (o.name || "") + " (" + o.user_id + ")"]);
  L.forEach(([v, t]) => { const o = document.createElement("option"); o.value = v; o.textContent = t; s.appendChild(o); });
}
$("#acRole").onchange = fillRef;
const PWERR = { too_short: "حداقل ۴ حرف", reserved: "این رمز مجاز نیست", in_use: "این رمز برای کس دیگری ثبت شده", no_such_masseur: "ماسور وجود ندارد", no_such_operator: "اپراتور وجود ندارد", bad_old: "رمز فعلی اشتباه است" };
$("#acSet").onclick = async () => { const r = await api("/admin/accounts", "POST", { role: $("#acRole").value, ref: $("#acRef").value, password: $("#acPw").value.trim() }); toast(r.ok ? "ثبت شد" : PWERR[r.error] || "نشد"); if (r.ok) { $("#acPw").value = ""; loadAcc(); } };
$("#mGo").onclick = async () => { const r = await api("/admin/master", "POST", { old: $("#mOld").value, new: $("#mNew").value }); toast(r.ok ? "رمز مادر عوض شد؛ دوباره وارد شو" : PWERR[r.error] || "نشد"); if (r.ok) setTimeout(() => logout(true), 1200); };

/* --- تنظیمات --- */
$("#stBat").onclick = () => NATIVE && Android.batterySettings();
$("#stFull").onclick = () => NATIVE && Android.fullScreenSettings();
$("#muteChk").onchange = async (e) => { await api("/app/mute", "POST", { muted: e.target.checked }); toast("ثبت شد"); };

/* ---------------- شروع ---------------- */
show("home"); nav = ["home"]; loadPrices(); setInterval(() => { if (!$("#home").classList.contains("hidden")) loadPrices(); }, 15000);
$("#btnBuy").textContent = "خرید"; $("#btnSell").textContent = "فروش";
if (S && NATIVE) Android.saveSession(BASE, S.token, S.role);
