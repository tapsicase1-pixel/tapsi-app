package app.nerkh.live

import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.os.Build
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView

/** صفحه‌ی تمام‌صفحه‌ی زنگ؛ تا وقتی «دیدم» زده نشود زنگ ادامه دارد. */
class AlarmActivity : Activity() {
    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        if (Build.VERSION.SDK_INT >= 27) { setShowWhenLocked(true); setTurnScreenOn(true) }
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON or WindowManager.LayoutParams.FLAG_DISMISS_KEYGUARD)
        val ticker = intent.getStringExtra("ticker") ?: "قیمت‌ها در حال تغییر است"
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER
            setBackgroundColor(Color.parseColor("#0f1720")); setPadding(48, 48, 48, 48)
            layoutDirection = View.LAYOUT_DIRECTION_RTL
        }
        root.addView(TextView(this).apply {
            text = ticker; textSize = 28f; setTextColor(Color.WHITE); gravity = Gravity.CENTER
        })
        root.addView(Button(this).apply {
            text = "دیدم"; textSize = 22f
            setOnClickListener {
                startService(Intent(this@AlarmActivity, AlarmService::class.java).setAction(AlarmService.ACT_SEEN))
                finish()
            }
        }, LinearLayout.LayoutParams(-1, 220).apply { topMargin = 96 })
        root.addView(Button(this).apply {
            text = "ورود به برنامه"; textSize = 16f
            setOnClickListener { startActivity(Intent(this@AlarmActivity, MainActivity::class.java)); finish() }
        }, LinearLayout.LayoutParams(-1, 140).apply { topMargin = 32 })
        setContentView(root)
    }
    override fun onNewIntent(i: Intent?) { super.onNewIntent(i); setIntent(i) }
    override fun onBackPressed() { /* با Back بسته نمی‌شود؛ فقط «دیدم» */ }
}
